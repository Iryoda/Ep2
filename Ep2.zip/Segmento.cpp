#include "Segmento.h"

Segmento::   Segmento(int portaDeOrigem, int portaDeDestino, string dado):
    portaDeDestino(portaDeDestino), portaDeOrigem(portaDeOrigem), dado(dado)
{
    //ctor
}

Segmento::~Segmento()
{
    //dtor
}
