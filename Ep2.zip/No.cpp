#include "No.h"

No::No(int endereco) : endereco(endereco)
{
    //ctor
}

No::~No()
{
    //dtor
}
