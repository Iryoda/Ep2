#include <iostream>

#include "Datagrama.h"
#include "TabelaDeRepasse.h"
/*
 Processo
> Navegador
> ServidorWeb
> Tabela de Repasse
> Datagrama




*/
using namespace std;

int main()
{
    No* n1 = new No(2);
    Segmento* s1 = new  Segmento( 1, 2, "dado1");
    Datagrama* d1 = new Datagrama(1, 2, 3, s1);

    TabelaDeRepasse* T1 = new TabelaDeRepasse();

    T1->mapear(1, n1);


    cout <<T1->getDestino(1)->endereco<< endl;


    cout << T1->getQuantidadeDeAdjacentes() << endl;


}
