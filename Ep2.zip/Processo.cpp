#include "Processo.h"

Processo::Processo(int endereco, int porta, Roteador* gateway):
    endereco(endereco), porta(porta);
{
    this->gateway = gateway;
}

int Processo::getEndereco()
{
    return endereco;
}

int Processo::getPorta()
{
    return porta;
}

int Processo::getTtlPadrao()
{
    return padrao;
}

void Processo::setTtlPadrao(int padrao)
{
    this-> padrao = padrao;
}

void Processo::receber(int origem, Segmento* mensagem)
{
  return origem;
}

void Processo::imprimir()
{

}

Processo::~Processo()
{

}
